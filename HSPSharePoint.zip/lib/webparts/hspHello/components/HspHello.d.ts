import * as React from 'react';
import type { IHspHelloProps } from './IHspHelloProps';
export default class HspHello extends React.Component<IHspHelloProps, {}> {
    render(): React.ReactElement<IHspHelloProps>;
}
//# sourceMappingURL=HspHello.d.ts.map