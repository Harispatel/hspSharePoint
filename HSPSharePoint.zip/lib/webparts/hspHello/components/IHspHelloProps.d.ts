export interface IHspHelloProps {
    description: string;
    isDarkTheme: boolean;
    environmentMessage: string;
    hasTeamsContext: boolean;
    userDisplayName: string;
}
//# sourceMappingURL=IHspHelloProps.d.ts.map