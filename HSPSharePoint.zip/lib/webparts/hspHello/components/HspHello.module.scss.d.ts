declare const styles: {
    hspHello: string;
    teams: string;
    welcome: string;
    welcomeImage: string;
    links: string;
};
export default styles;
//# sourceMappingURL=HspHello.module.scss.d.ts.map