/* tslint:disable */
require("./HspHello.module.css");
const styles = {
  hspHello: 'hspHello_7f2d2c74',
  teams: 'teams_7f2d2c74',
  welcome: 'welcome_7f2d2c74',
  welcomeImage: 'welcomeImage_7f2d2c74',
  links: 'links_7f2d2c74'
};

export default styles;
/* tslint:enable */